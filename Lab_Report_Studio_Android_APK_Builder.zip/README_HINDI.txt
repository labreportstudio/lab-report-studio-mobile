LAB REPORT STUDIO — ANDROID APK BUILDER

यह Android Studio / Python के बिना GitHub Actions पर APK बनाने वाला प्रोजेक्ट है।
यह अभी signed Play Store APK नहीं, बल्कि testing के लिए debug APK बनाता है।

मोबाइल से APK पाने के लिए:
1. GitHub में नया Public या Private repository बनाएँ।
2. इस ZIP को extract करके इसकी सभी files/folders repository की main branch में upload करें। ZIP को अकेले upload न करें।
3. GitHub repository > Actions खोलें।
4. "Build Android APK" workflow चुनें और Run workflow दबाएँ।
5. Build पूरा होने पर workflow run खोलें; नीचे Artifacts में Lab-Report-Studio-APK डाउनलोड करें।
6. ZIP artifact extract करें; app-debug.apk खोलकर Android की अनुमति देकर install करें।

नोट: यदि GitHub मोबाइल पर folder upload मुश्किल हो, तो GitHub Desktop/computer की जरूरत पड़ सकती है या किसी trusted helper से एक बार upload करवाएँ। ChatGPT से सीधे signed APK compile/host नहीं किया गया है।

इस APK में डेमो डेटा मोबाइल के ऐप के local storage में रहता है। ऐप uninstall करने पर data मिट सकता है; Settings से Backup लें।
Clinical safety: parameter catalogue starter-only है; reference intervals को local method/analyzer/SOP और authorized pathologist से verify करें। Report draft output है, authorized review के बिना clinical use न करें।
