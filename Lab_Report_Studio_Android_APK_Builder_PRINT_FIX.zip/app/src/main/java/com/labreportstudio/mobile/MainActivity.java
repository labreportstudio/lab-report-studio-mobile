package com.labreportstudio.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.content.Context;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private WebView webView;
    private WebView printWebView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF123B55);
        getWindow().setNavigationBarColor(0xFF123B55);
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    public class Bridge {
        @JavascriptInterface public void printReport(final String reportHtml) {
            runOnUiThread(() -> {
                if (printWebView != null) {
                    try { ((ViewGroup) printWebView.getParent()).removeView(printWebView); } catch (Exception ignored) {}
                    printWebView.destroy();
                }
                printWebView = new WebView(MainActivity.this);
                printWebView.getSettings().setJavaScriptEnabled(false);
                addContentView(printWebView, new ViewGroup.LayoutParams(1, 1));
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        if (pm != null) {
                            String jobName = "Lab Report - PDF";
                            pm.print(jobName, view.createPrintDocumentAdapter(jobName),
                                new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setResolution(new PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                                    .setMinMargins(new PrintAttributes.Margins(42, 42, 42, 42))
                                    .build());
                        }
                    }
                });
                printWebView.loadDataWithBaseURL("file:///android_asset/www/", reportHtml, "text/html", "UTF-8", null);
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
