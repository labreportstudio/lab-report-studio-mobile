LABSAATHI — ANDROID APK BUILDER (UPDATED PRINT FIX)

यह Android Studio / Python के बिना GitHub Actions पर APK बनाने वाला प्रोजेक्ट है।
यह testing के लिए debug APK बनाता है।

अपडेट:
- PDF print में केवल report content भेजा जाता है, पूरी app screen नहीं।
- A4 page layout, repeatable table header और page-break-safe rows जोड़े गए हैं।
- Report preview/save के लिए सभी parameter results भरना जरूरी है, ताकि खाली result वाली अधूरी report न बने।
- Android print bridge अलग report-only WebView से PDF बनाता है।

महत्वपूर्ण clinical सुरक्षा:
यह शुरुआती demo है, प्रमाणित LIS नहीं। Parameter catalogue और reference intervals को local lab SOP, analyzer, method, age/sex/pregnancy और authorized pathologist से verify करें। Report फिलहाल DRAFT है; authorized review/sign-off के बिना clinical use न करें।

डेटा ऐप के local storage में रहता है। ऐप uninstall करने से पहले Settings से backup लें।

Branding update: LabSaathi logo is included in the Android launcher icon, app header, and dashboard hero.
